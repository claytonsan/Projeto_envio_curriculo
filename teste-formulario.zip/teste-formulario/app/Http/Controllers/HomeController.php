<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\EscolaridadeService;
use App\Services\FormularioService;


class HomeController extends Controller
{
    public function index()
    {
        $Escolaridade = new EscolaridadeService();
        $data['escolaridade'] = ['0' => 'Selecione uma Escolaridade'] + $Escolaridade->buscarEscolaridadeDescricao();
        return view('tela_inicial',$data);
    }

    public function create()
    {
        //
    }


    public function store(Request $request)
    {
        $dados = $request->all();
        $Formulario = new FormularioService();
        $Formulario->salvarFormulario($dados);
        $data['success'] = true;
        return response()->json(['success' => true], 200);
    }


    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }

    public function lista_curriculos()
    {
        $FormularioService      = new FormularioService();
        $Escolaridade           = new EscolaridadeService();
        $data['candidatos']     = $FormularioService->buscarFormularios();
        $data['escolaridade']   = $Escolaridade->buscarEscolaridadeDescricao();
        return view('tela_formularios',$data);
    }

}
