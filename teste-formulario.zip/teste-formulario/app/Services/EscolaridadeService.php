<?php

namespace App\Services;

use App\Escolaridade;

class EscolaridadeService {

    public function buscarEscolaridadeDescricao()
    {
        $escolaridade = Escolaridade::pluck('descricao', 'id')->toArray();
        if($escolaridade){
            return $escolaridade;
        }else{
            return false;
        }
    }

}
